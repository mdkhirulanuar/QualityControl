// reset.js - reset form and interface
