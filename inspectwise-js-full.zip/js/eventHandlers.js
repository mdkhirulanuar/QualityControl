// eventHandlers.js - bind all UI actions
