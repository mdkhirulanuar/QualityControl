// photo.js - handle photo upload, preview, remove
