// annotation.js - canvas drawing and annotation
