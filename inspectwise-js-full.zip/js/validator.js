// validator.js - validation logic
