// sampling.js - AQL sampling calculations
