// serviceWorker.js - PWA registration
