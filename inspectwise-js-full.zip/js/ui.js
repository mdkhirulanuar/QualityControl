// ui.js - fadeIn/fadeOut, populate dropdowns, error messages
