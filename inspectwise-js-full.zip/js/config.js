// config.js - your constants and AQL tables here
