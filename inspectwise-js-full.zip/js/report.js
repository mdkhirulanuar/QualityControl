// report.js - verdict, HTML report, PDF, print
